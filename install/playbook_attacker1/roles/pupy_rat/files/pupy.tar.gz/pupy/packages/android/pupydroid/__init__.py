import camera
import text_to_speech
import vibrator
